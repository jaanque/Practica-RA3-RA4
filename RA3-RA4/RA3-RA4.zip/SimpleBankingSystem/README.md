# Sistema bancari simple

## Descripció

Escriu aquí una breu descripció del que fa el programa.

## Funcionalitats

1.
2.
3.
4.
...

## Estructura del Codi

### `Main.java`
....

### `Account.java`
....

### `Proves.java`